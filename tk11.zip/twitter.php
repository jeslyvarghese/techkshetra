<?php
$twitter_feeds = file_get_contents("search.json");
echo $twitter_feeds;
?>
